package com.primeiro.primeiroexemplo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiroexemploApplicationTests {

	@Test
	void contextLoads() {
	}

}
